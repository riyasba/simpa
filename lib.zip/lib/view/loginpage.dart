import 'package:flutter/material.dart';
import 'package:flutter/src/widgets/framework.dart';
import 'package:flutter/src/widgets/placeholder.dart';
import 'package:simpa/view/constands/constands.dart';
import 'package:simpa/widgets/textfield.dart';

class loginpage extends StatelessWidget {
  const loginpage({super.key});

  @override
  Widget build(BuildContext context) {
    var size = MediaQuery.of(context).size;
    return Scaffold(
      body: Stack(
        children: [
          Container(
            width: size.width,
            child: Image.asset(
              'assets/images/Ellipse 1 (1).jpg',
              fit: BoxFit.contain,
            ),
          ),
          Padding(
            padding: const EdgeInsets.only(left: 37, right: 37),
            child: Center(
              child: Container(
                height: 500,
                width: double.infinity,
                decoration: BoxDecoration(
                    color: Colors.white,
                    borderRadius: BorderRadius.circular(15),
                    boxShadow: const [
                      BoxShadow(
                        blurRadius: 3.5,
                        color: Color.fromARGB(255, 187, 185, 185),
                      ),
                    ]),
                child: Column(
                  children: [
                    ksizedbox10,
                    Text(
                      'Login',
                      style: ktextstyle,
                    ),
                    ksizedbox10,
                    Text(
                      'Welcome back to SIPMAA ',
                      style: ktextstyle22,
                    ),
                    Text(
                      'HR community ',
                      style: ktextstyle22,
                    ),
                    ksizedbox10,
                    textformfield(
                      text: 'Enter Email Id',
                      textt: 'Email ID',
                    ),
                    //  ksizedbox10,
                    textformfield(
                      text: 'Enter Password',
                      textt: "Password",
                    ),Row(mainAxisAlignment: MainAxisAlignment.end,
                      children: [
                        Text('Forgot Password?',style: TextStyle(color:Colors.grey),),
                      ],
                    )
                  ],
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }
}
