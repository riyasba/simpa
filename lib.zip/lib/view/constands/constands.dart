import 'package:flutter/material.dart';

//text style
TextStyle ktextstyle=TextStyle(fontWeight: FontWeight.bold,fontSize: 25);
TextStyle ktextstyle22=TextStyle(fontWeight: FontWeight.w600,fontSize: 22);





//sized box
const SizedBox ksizedbox10=SizedBox(height: 10,);



//colors
